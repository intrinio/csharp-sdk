# Intrinio.SDK.Model.AccumulationDistributionIndexTechnicalValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateTime** | **DateTime?** | The date_time of the observation | [optional] 
**Adi** | **float?** | The Accumulation/Distribution Index calculation value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

