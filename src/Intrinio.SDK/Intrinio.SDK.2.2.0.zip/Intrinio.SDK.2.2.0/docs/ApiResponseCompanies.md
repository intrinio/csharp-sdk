# Intrinio.SDK.Model.ApiResponseCompanies
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Companies** | [**List&lt;CompanySummary&gt;**](CompanySummary.md) |  | [optional] 
**NextPage** | **string** | The token required to request the next page of the data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

