# Intrinio.SDK.Model.ApiResponseCompaniesSearch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Companies** | [**List&lt;CompanySummary&gt;**](CompanySummary.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

