# Intrinio.SDK.Model.ApiResponseCompanyFilings
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filings** | [**List&lt;FilingSummary&gt;**](FilingSummary.md) |  | [optional] 
**Company** | [**CompanySummary**](CompanySummary.md) |  | [optional] 
**NextPage** | **string** | The token required to request the next page of the data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

