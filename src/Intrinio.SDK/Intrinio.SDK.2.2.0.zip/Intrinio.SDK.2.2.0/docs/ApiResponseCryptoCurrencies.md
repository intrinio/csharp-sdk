# Intrinio.SDK.Model.ApiResponseCryptoCurrencies
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Currencies** | [**List&lt;CryptoCurrency&gt;**](CryptoCurrency.md) | A list of Crypto Currencies for the given Crypto Exchange sorted by alphabetically by symbol. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

