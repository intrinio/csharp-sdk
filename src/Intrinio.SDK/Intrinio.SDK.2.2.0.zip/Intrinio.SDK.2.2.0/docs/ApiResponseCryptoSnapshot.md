# Intrinio.SDK.Model.ApiResponseCryptoSnapshot
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Pair** | [**CryptoPairSummary**](CryptoPairSummary.md) |  | [optional] 
**Exchange** | [**CryptoExchangeSummary**](CryptoExchangeSummary.md) |  | [optional] 
**Snapshot** | [**CryptoSnapshot**](CryptoSnapshot.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

