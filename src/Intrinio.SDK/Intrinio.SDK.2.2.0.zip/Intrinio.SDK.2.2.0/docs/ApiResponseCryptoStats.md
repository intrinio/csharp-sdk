# Intrinio.SDK.Model.ApiResponseCryptoStats
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Stats** | [**List&lt;CryptoStat&gt;**](CryptoStat.md) | A list of Crypto Currencies and their stats. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

