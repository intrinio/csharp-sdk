# Intrinio.SDK.Model.ApiResponseOptions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Options** | [**List&lt;Option&gt;**](Option.md) | A list of options contracts with the given symbol | [optional] 
**NextPage** | **string** | The token required to request the next page of the data | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

