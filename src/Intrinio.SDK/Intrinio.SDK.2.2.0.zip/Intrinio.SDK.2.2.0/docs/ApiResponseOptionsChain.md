# Intrinio.SDK.Model.ApiResponseOptionsChain
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Chains** | [**List&lt;OptionChain&gt;**](OptionChain.md) | A list of options for the provided expiration date their respective option prices. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

