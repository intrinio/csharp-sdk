# Intrinio.SDK.Model.ApiResponseOptionsExpirations
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Expirations** | **List&lt;string&gt;** | A list of option expiration dates in descending order | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

