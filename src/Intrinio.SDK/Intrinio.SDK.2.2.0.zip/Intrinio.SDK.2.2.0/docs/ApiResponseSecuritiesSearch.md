# Intrinio.SDK.Model.ApiResponseSecuritiesSearch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Securities** | [**List&lt;SecuritySummary&gt;**](SecuritySummary.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

