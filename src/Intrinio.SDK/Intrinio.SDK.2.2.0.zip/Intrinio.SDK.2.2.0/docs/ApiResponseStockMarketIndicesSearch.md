# Intrinio.SDK.Model.ApiResponseStockMarketIndicesSearch
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Indices** | [**List&lt;StockMarketIndexSummary&gt;**](StockMarketIndexSummary.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

