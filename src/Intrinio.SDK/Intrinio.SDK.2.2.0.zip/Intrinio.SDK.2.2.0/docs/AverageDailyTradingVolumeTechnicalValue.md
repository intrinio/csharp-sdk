# Intrinio.SDK.Model.AverageDailyTradingVolumeTechnicalValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateTime** | **DateTime?** | The date_time of the observation | [optional] 
**Adtv** | **float?** | The Average Daily Trading Volume calculation value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

