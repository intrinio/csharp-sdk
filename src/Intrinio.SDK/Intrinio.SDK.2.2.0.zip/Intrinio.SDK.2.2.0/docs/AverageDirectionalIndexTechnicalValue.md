# Intrinio.SDK.Model.AverageDirectionalIndexTechnicalValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateTime** | **DateTime?** | The date_time of the observation | [optional] 
**Adx** | **float?** | The Average Directional Index value | [optional] 
**DiNeg** | **float?** | The Minus Directional Indicator value | [optional] 
**DiPos** | **float?** | The Plus Directional Indicator value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

