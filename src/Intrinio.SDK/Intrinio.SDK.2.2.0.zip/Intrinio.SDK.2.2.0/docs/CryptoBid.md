# Intrinio.SDK.Model.CryptoBid
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Price** | **decimal?** | The bid price of the book entry. | [optional] 
**Size** | **decimal?** | The size for the bid price of the book entry. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

