# Intrinio.SDK.Model.CryptoExchangeSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The Crypto Exchange name. | [optional] 
**Code** | **string** | The Crypto Exchange code. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

