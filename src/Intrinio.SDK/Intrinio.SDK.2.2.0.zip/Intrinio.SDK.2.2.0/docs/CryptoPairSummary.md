# Intrinio.SDK.Model.CryptoPairSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | The Crypto Currency Pair name. | [optional] 
**Code** | **string** | The Crypto Currency Pair code. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

