# Intrinio.SDK.Model.DataTagSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | The Intrinio ID for the Data Tag | [optional] 
**Name** | **string** | The readable name of the Data Tag | [optional] 
**Tag** | **string** | The code-name of the Data Tag | [optional] 
**Unit** | **string** | The unit of the Data Tag | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

