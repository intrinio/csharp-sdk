# Intrinio.SDK.Model.ForexCurrency
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** | The ISO 4217 currency code | [optional] 
**Name** | **string** | The name of the currency | [optional] 
**Country** | **string** | The country in which the currency is used | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

