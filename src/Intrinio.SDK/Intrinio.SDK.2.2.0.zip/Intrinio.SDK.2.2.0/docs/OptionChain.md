# Intrinio.SDK.Model.OptionChain
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Option** | [**Option**](Option.md) |  | [optional] 
**Price** | [**OptionPrice**](OptionPrice.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

