# Intrinio.SDK.Model.ReportedFinancialDimension
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Axis** | **string** | The axis of the dimension | [optional] 
**Member** | **string** | The member of the axis | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

