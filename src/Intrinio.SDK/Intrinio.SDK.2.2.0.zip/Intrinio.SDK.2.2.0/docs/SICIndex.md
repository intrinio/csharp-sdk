# Intrinio.SDK.Model.SICIndex
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Intrinio ID for the Index | [optional] 
**Symbol** | **string** | The symbol used to identify the Index | [optional] 
**Name** | **string** | The name of the Index | [optional] 
**Continent** | **string** | The continent of the country of focus for the Index | [optional] 
**Country** | **string** | The country of focus for the Index | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

