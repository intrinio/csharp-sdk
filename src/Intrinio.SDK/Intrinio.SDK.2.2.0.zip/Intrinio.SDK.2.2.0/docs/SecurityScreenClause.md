# Intrinio.SDK.Model.SecurityScreenClause
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Field** | **string** | The field to use when screening, such as an Intrinio Data Tag | [optional] 
**_Operator** | **string** | The logic operator to use when screening | [optional] 
**Value** | **string** | The value to screen by | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

