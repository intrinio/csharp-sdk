# Intrinio.SDK.Model.SecurityScreenResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Security** | [**SecuritySummary**](SecuritySummary.md) |  | [optional] 
**Data** | [**List&lt;SecurityScreenResultData&gt;**](SecurityScreenResultData.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

