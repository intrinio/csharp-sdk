# Intrinio.SDK.Model.StandardizedFinancial
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DataTag** | [**DataTagSummary**](DataTagSummary.md) |  | [optional] 
**Value** | **decimal?** | The value for the Data Tag within the scope of the Fundamental | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

