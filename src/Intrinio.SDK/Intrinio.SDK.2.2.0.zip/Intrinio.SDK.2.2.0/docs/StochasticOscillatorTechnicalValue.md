# Intrinio.SDK.Model.StochasticOscillatorTechnicalValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateTime** | **DateTime?** | The date_time of the observation | [optional] 
**Sr** | **float?** | The Stochastic Oscillator calculation value | [optional] 
**SrSignal** | **float?** | The Stochastic Oscillator signal line value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

