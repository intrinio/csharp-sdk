# Intrinio.SDK.Model.VolumeWeightedAveragePriceValue
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateTime** | **DateTime?** | The date and time of the observation | [optional] 
**Vwap** | **float?** | The Volume Weighted Average Price calculation value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

